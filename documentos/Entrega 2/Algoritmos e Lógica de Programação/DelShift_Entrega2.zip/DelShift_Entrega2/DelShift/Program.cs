using System;

class Program
{
    static int energia = 5;
    static int pontos = 0;
    static int faseAtual = 1;
    static int totalFases = 3;
    static bool jogando = true;

    static void ExibirAbertura()
    {
        Console.WriteLine("============================================");
        Console.WriteLine("                  DELSHIFT                  ");
        Console.WriteLine("         Fuga do Laboratorio - FECAP        ");
        Console.WriteLine("============================================");
        Console.WriteLine("Voce e um aluno e dormiu na faculdade.");
        Console.WriteLine("O laboratorio de informatica foi trancado!");
        Console.WriteLine("Para destrancar a porta, resolva os 3 desafios");
        Console.WriteLine("baseados em investigacao forense digital.");
        Console.WriteLine();
        Console.WriteLine("Energia inicial: " + energia);
        Console.WriteLine("Acertou = ganha pontos | Errou = perde energia");
        Console.WriteLine("Digite 'sair' a qualquer momento para desistir.");
        Console.WriteLine("============================================\n");
    }

    static void ExibirStatus()
    {
        Console.WriteLine("Energia: " + energia + " | Pontos: " + pontos);
    }

    static void ExibirFinal()
    {
        Console.WriteLine("\n============================================");
        Console.WriteLine("              FIM DE JOGO                   ");
        Console.WriteLine("============================================");
        Console.WriteLine("Pontuacao final: " + pontos);
        Console.WriteLine("Energia restante: " + energia);
        Console.WriteLine("Pressione qualquer tecla para sair...");
        Console.ReadKey();
    }

    static void RegistrarAcerto(int valor)
    {
        Console.WriteLine(">> Correto! +" + valor + " pontos.");
        pontos = pontos + valor;
    }

    static void RegistrarErro()
    {
        Console.WriteLine(">> Errado! -1 energia.");
        energia = energia - 1;
    }

    static void VerificarDerrota()
    {
        if (energia <= 0)
        {
            Console.WriteLine("\n>>> Sua energia chegou a 0. Voce desmaiou no lab.");
            Console.WriteLine(">>> Vai ter que esperar alguem abrir a porta amanha. <<<");
            jogando = false;
        }
    }

    static void ExecutarFase1()
    {
        Console.WriteLine("\n-------- FASE 1: O Filtro de Ruido --------");
        Console.WriteLine("No computador do lab, voce encontra um desafio");
        Console.WriteLine("de analise de frequencia sonora. Para avancar,");
        Console.WriteLine("prove que um audio de chantagem e falso.\n");

        Console.Write("1) Para provar que o audio e falso, o que voce sobrepoe? (onda/imagem/texto): ");
        string r1 = LerEntrada();
        if (VerificarSaida(r1)) { return; }
        if (r1 == "onda")
        {
            RegistrarAcerto(10);
        }
        else
        {
            RegistrarErro();
        }
        VerificarDerrota();
        if (jogando == false) { return; }

        Console.Write("2) Ao limpar o ruido de fundo, qual som aparece? (sino/badalar/buzina): ");
        string r2 = LerEntrada();
        if (VerificarSaida(r2)) { return; }
        if (r2 == "badalar")
        {
            RegistrarAcerto(10);
        }
        else
        {
            RegistrarErro();
        }
        VerificarDerrota();
    }

    static void ExecutarFase2()
    {
        Console.WriteLine("\n-------- FASE 2: O Mapa de Artefatos --------");
        Console.WriteLine("O segundo computador mostra um video deepfake.");
        Console.WriteLine("Use o Mapa de Calor para achar erros de renderizacao.\n");

        Console.Write("1) Onde esta a inconsistencia principal do deepfake? (cabelo/olhos/roupa): ");
        string r1 = LerEntrada();
        if (VerificarSaida(r1)) { return; }
        if (r1 == "olhos")
        {
            RegistrarAcerto(15);
        }
        else
        {
            RegistrarErro();
        }
        VerificarDerrota();
        if (jogando == false) { return; }

        Console.Write("2) O erro de renderizacao aparece no reflexo de que? (espelho/oculos/janela): ");
        string r2 = LerEntrada();
        if (VerificarSaida(r2)) { return; }
        if (r2 == "oculos" || r2 == "óculos")
        {
            RegistrarAcerto(15);
        }
        else
        {
            RegistrarErro();
        }
        VerificarDerrota();
    }

    static void ExecutarFase3()
    {
        Console.WriteLine("\n-------- FASE 3: A Quebra do Hash --------");
        Console.WriteLine("O ultimo desafio: um labirinto logico de rede.");
        Console.WriteLine("Conecte os nos sem disparar o firewall.\n");

        Console.Write("1) Para nao disparar o firewall, conecte os nos: (todos/em sequencia/aleatorio): ");
        string r1 = LerEntrada();
        if (VerificarSaida(r1)) { return; }
        if (r1 == "em sequencia" || r1 == "em sequência")
        {
            RegistrarAcerto(20);
        }
        else
        {
            RegistrarErro();
        }
        VerificarDerrota();
        if (jogando == false) { return; }

        Console.Write("2) O que voce rastreia ate o servidor escondido? (senha/ip/email): ");
        string r2 = LerEntrada();
        if (VerificarSaida(r2)) { return; }
        if (r2 == "ip")
        {
            RegistrarAcerto(20);
        }
        else
        {
            RegistrarErro();
        }
        VerificarDerrota();
    }

    static void ExecutarFaseAtual()
    {
        if (faseAtual == 1)
        {
            ExecutarFase1();
        }
        else if (faseAtual == 2)
        {
            ExecutarFase2();
        }
        else if (faseAtual == 3)
        {
            ExecutarFase3();
        }
    }

    static void AvancarFase()
    {
        if (faseAtual >= totalFases)
        {
            Console.WriteLine("\n>>> Voce resolveu todos os desafios! <<<");
            Console.WriteLine(">>> A porta do laboratorio destravou. VOCE ESCAPOU! <<<");
            jogando = false;
        }
        else
        {
            faseAtual = faseAtual + 1;
        }
    }

    static string LerEntrada()
    {
        string entrada = Console.ReadLine();
        if (entrada == null)
        {
            return "";
        }
        return entrada.Trim().ToLower();
    }

    static bool VerificarSaida(string entrada)
    {
        if (entrada == "sair")
        {
            Console.WriteLine(">> Voce desistiu. Vai esperar alguem abrir a porta.");
            jogando = false;
            return true;
        }
        return false;
    }

    static bool JogoEmAndamento()
    {
        return jogando;
    }

    static void Main()
    {
        ExibirAbertura();

        while (JogoEmAndamento())
        {
            ExibirStatus();
            ExecutarFaseAtual();

            if (JogoEmAndamento())
            {
                AvancarFase();
            }
        }

        ExibirFinal();
    }
}
