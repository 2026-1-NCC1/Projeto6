// =====================================================================
// DelShift - Versao Console (Algoritmos e Logica de Programacao - FECAP)
// Projeto Interdisciplinar - Jogos Digitais
// Aluna: Nathalia Inocencio
//
// Adaptacao em console fiel ao GDD do DelShift:
//  - Voce e o perito em uma delegacia investigando uma chantagem contra
//    a vitima Elena. Ha 3 suspeitos e um TEMPO limite (em vez de energia).
//  - Verbos do core loop: mover-se (WASD), selecionar, utilizar, manipular.
//  - 3 puzzles forenses dao 3 pistas. Com as pistas voce acusa o culpado.
//  - Erro em puzzle ou acusacao errada = corte de tempo (GDD).
//  - Game over quando o tempo chega a 0. Vitoria ao acusar o suspeito certo.
//
// Conceitos da disciplina:
//  - Variaveis (int, bool, string), operadores aritmeticos/relacionais/logicos
//  - Estruturas condicionais (if / else if / else)
//  - Repeticao com while (loop principal do jogo)
// =====================================================================

using System;

class Program
{
    static void Main()
    {
        // ---------- VARIAVEIS PRINCIPAIS ----------
        int tempo = 60;          // minutos restantes ate a chantagem ser publicada
        int velocidade = 1;      // mesma "velocidade = 1" do fluxograma de movimentacao
        int x = 1, y = 1;        // posicao do perito no mapa 3x3 da delegacia
        int pistas = 0;          // quantas pistas o jogador ja coletou
        bool puzzle1Ok = false;  // Filtro de Ruido
        bool puzzle2Ok = false;  // Mapa de Artefatos (Deepfake)
        bool puzzle3Ok = false;  // Quebra do Hash
        bool jogando = true;
        string input;

        // Salas da delegacia (mapa 3x3) - cada sala tem 1 puzzle ou e neutra
        string[,] salas = {
            { "Escritorio do Perito", "Corredor",         "Sala de Audio"     },
            { "Arquivo",              "Sala de Provas",   "Sala de Video"     },
            { "Copa",                 "Sala de Servidor", "Sala de Suspeitos" }
        };

        Console.WriteLine("============================================");
        Console.WriteLine("                  DELSHIFT                  ");
        Console.WriteLine("        Investigacao Forense Digital        ");
        Console.WriteLine("============================================");
        Console.WriteLine("Voce e o perito responsavel pelo caso.");
        Console.WriteLine("A vitima Elena esta sendo chantageada com um");
        Console.WriteLine("conteudo falso. Voce tem " + tempo + " minutos antes");
        Console.WriteLine("que o material seja publicado.");
        Console.WriteLine();
        Console.WriteLine("Suspeitos: 1) Marco   2) Helena   3) Rafael");
        Console.WriteLine();
        Console.WriteLine("Comandos: W A S D = mover | E = examinar sala");
        Console.WriteLine("          P = acusar culpado | Q = desistir");
        Console.WriteLine("============================================\n");

        // ---------- LOOP PRINCIPAL (WHILE) ----------
        while (jogando)
        {
            Console.WriteLine("\n[ Tempo: " + tempo + " min | Pistas: " + pistas + "/3 ]");
            Console.WriteLine("Local atual: " + salas[y, x] + "  (x=" + x + ", y=" + y + ")");
            Console.Write("Acao: ");
            input = Console.ReadLine();
            if (input == null) { jogando = false; break; }
            input = input.Trim().ToLower();

            // ---------- MOVIMENTACAO (segue o fluxograma WASD) ----------
            if (input == "w")
            {
                if (y - velocidade >= 0) { y = y - velocidade; }
                else { Console.WriteLine(">> Limite da cena. Movimento bloqueado."); }
            }
            else if (input == "s")
            {
                if (y + velocidade <= 2) { y = y + velocidade; }
                else { Console.WriteLine(">> Limite da cena. Movimento bloqueado."); }
            }
            else if (input == "a")
            {
                if (x - velocidade >= 0) { x = x - velocidade; }
                else { Console.WriteLine(">> Limite da cena. Movimento bloqueado."); }
            }
            else if (input == "d")
            {
                if (x + velocidade <= 2) { x = x + velocidade; }
                else { Console.WriteLine(">> Limite da cena. Movimento bloqueado."); }
            }
            // ---------- EXAMINAR / SELECIONAR OBJETO (fluxograma de selecao) ----------
            else if (input == "e")
            {
                string sala = salas[y, x];
                Console.WriteLine(">> O cursor passa pelos objetos da sala...");

                if (sala == "Sala de Audio" && puzzle1Ok == false)
                {
                    Console.WriteLine(">> Objeto destacado: gravacao da chantagem.");
                    Console.WriteLine("PUZZLE 1 - O Filtro de Ruido");
                    Console.WriteLine("Para provar que o audio e falso, sobreponha a onda");
                    Console.WriteLine("da chantagem com a voz real da Elena.");
                    Console.Write("Ao limpar o ruido, qual som ambiente aparece? (sino/badalar/buzina): ");
                    string r = Console.ReadLine().Trim().ToLower();
                    if (r == "badalar")
                    {
                        Console.WriteLine(">> PISTA OBTIDA: relogio antigo - so existe na casa do Marco.");
                        puzzle1Ok = true;
                        pistas = pistas + 1;
                    }
                    else
                    {
                        Console.WriteLine(">> Analise errada. -10 minutos (corte de tempo).");
                        tempo = tempo - 10;
                    }
                }
                else if (sala == "Sala de Video" && puzzle2Ok == false)
                {
                    Console.WriteLine(">> Objeto destacado: video deepfake da Elena.");
                    Console.WriteLine("PUZZLE 2 - O Mapa de Artefatos");
                    Console.WriteLine("Use o Mapa de Calor para achar o ponto de quebra do algoritmo.");
                    Console.Write("Onde aparece o erro de renderizacao? (cabelo/oculos/roupa): ");
                    string r = Console.ReadLine().Trim().ToLower();
                    if (r == "oculos" || r == "óculos")
                    {
                        Console.WriteLine(">> PISTA OBTIDA: reflexo nos oculos mostra um estudio de gravacao.");
                        puzzle2Ok = true;
                        pistas = pistas + 1;
                    }
                    else
                    {
                        Console.WriteLine(">> Analise errada. -10 minutos (corte de tempo).");
                        tempo = tempo - 10;
                    }
                }
                else if (sala == "Sala de Servidor" && puzzle3Ok == false)
                {
                    Console.WriteLine(">> Objeto destacado: terminal de rede.");
                    Console.WriteLine("PUZZLE 3 - A Quebra do Hash");
                    Console.WriteLine("Conecte os nos sem disparar o firewall e rastreie o IP.");
                    Console.Write("O que voce precisa rastrear ate o servidor escondido? (senha/ip/email): ");
                    string r = Console.ReadLine().Trim().ToLower();
                    if (r == "ip")
                    {
                        Console.WriteLine(">> PISTA OBTIDA: IP rastreado ate uma identidade falsa de TI.");
                        puzzle3Ok = true;
                        pistas = pistas + 1;
                    }
                    else
                    {
                        Console.WriteLine(">> Analise errada. -10 minutos (corte de tempo).");
                        tempo = tempo - 10;
                    }
                }
                else if (sala == "Sala de Suspeitos")
                {
                    Console.WriteLine(">> Marco (relojoeiro), Helena (atriz), Rafael (tecnico de TI).");
                    Console.WriteLine(">> Use 'P' para acusar quando tiver pistas suficientes.");
                }
                else
                {
                    Console.WriteLine(">> Nada de interessante aqui no momento.");
                }
            }
            // ---------- ACUSACAO FINAL ----------
            else if (input == "p")
            {
                if (pistas < 3)
                {
                    Console.WriteLine(">> Voce ainda nao tem pistas suficientes. (" + pistas + "/3)");
                    Console.WriteLine(">> Acusar agora pode causar um corte grande de tempo.");
                }
                Console.Write("Quem e o culpado? (1-Marco / 2-Helena / 3-Rafael): ");
                string acus = Console.ReadLine().Trim();
                // As 3 pistas (relogio + estudio + identidade falsa de TI)
                // se encaixam coerentemente em Rafael, o tecnico de TI.
                if (acus == "3")
                {
                    Console.WriteLine("\n>>> Voce acusou Rafael. As pistas se encaixam! <<<");
                    Console.WriteLine(">>> A chantagem foi impedida a tempo. VOCE VENCEU! <<<");
                    jogando = false;
                }
                else
                {
                    Console.WriteLine(">> Acusacao errada! Corte severo de tempo: -20 minutos.");
                    tempo = tempo - 20;
                }
            }
            else if (input == "q")
            {
                Console.WriteLine(">> Voce desistiu do caso.");
                jogando = false;
            }
            else
            {
                Console.WriteLine(">> Comando invalido. Use W A S D / E / P / Q.");
            }

            // Cada acao consome 1 minuto do tempo de investigacao
            if (jogando == true)
            {
                tempo = tempo - 1;
            }

            // ---------- CONDICAO DE GAME OVER ----------
            if (tempo <= 0 && jogando == true)
            {
                Console.WriteLine("\n>>> O tempo acabou. A chantagem foi publicada. GAME OVER. <<<");
                jogando = false;
            }
        }

        // ---------- TELA FINAL ----------
        Console.WriteLine("\n============================================");
        Console.WriteLine("              FIM DA INVESTIGACAO           ");
        Console.WriteLine("============================================");
        Console.WriteLine("Pistas coletadas: " + pistas + "/3");
        Console.WriteLine("Tempo restante:   " + tempo + " min");
        Console.WriteLine("Pressione qualquer tecla para sair...");
        Console.ReadKey();
    }
}
